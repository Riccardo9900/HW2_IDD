package lucenex;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Reader {

	public Reader() {
		// TODO Auto-generated constructor stub
	}

	public static String leggiContenuto(File file) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(file));
		String stringa = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");

		try {
			while((stringa = br.readLine()) != null) {
				stringBuilder.append(stringa);
				stringBuilder.append(ls);
			}
			return stringBuilder.toString();
		}
		finally {
			br.close();
		}
	}
}
