# lucenex

A few Lucene examples 